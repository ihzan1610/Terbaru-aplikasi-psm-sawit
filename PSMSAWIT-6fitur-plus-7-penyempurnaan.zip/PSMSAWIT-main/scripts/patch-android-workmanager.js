const fs = require('fs');
const path = require('path');

const config = JSON.parse(fs.readFileSync('capacitor.config.json', 'utf8'));
const appId = config.appId || 'com.psmsawit.timbangan';
const javaDir = path.join('android', 'app', 'src', 'main', 'java', ...appId.split('.'));
const gradlePath = path.join('android', 'app', 'build.gradle');
if (!fs.existsSync(gradlePath)) throw new Error('android/app/build.gradle tidak ditemukan. Jalankan cap add android terlebih dahulu.');
fs.mkdirSync(javaDir, { recursive: true });

let gradle = fs.readFileSync(gradlePath, 'utf8');
if (!gradle.includes('androidx.work:work-runtime')) {
  const depBlock = /dependencies\s*\{/;
  if (!depBlock.test(gradle)) throw new Error('Blok dependencies Gradle tidak ditemukan.');
  gradle = gradle.replace(depBlock, match => `${match}\n    implementation "androidx.work:work-runtime:2.10.0"`);
  fs.writeFileSync(gradlePath, gradle);
}

const worker = `package ${appId};

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.ExistingWorkPolicy;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.BackoffPolicy;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

public class PsmCloudSyncWorker extends Worker {
    private static final String PREFS = "psm_cloud_background_sync";
    private static final String KEY_QUEUE = "queue_json";
    private static final String TAG = "PsmCloudSyncWorker";

    public PsmCloudSyncWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    public static void enqueue(Context context, String url, String recordsJson, String deleteIdsJson) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("url", url);
        JSONArray incomingRecords = new JSONArray(recordsJson == null || recordsJson.isEmpty() ? "[]" : recordsJson);
        JSONArray incomingDeletes = new JSONArray(deleteIdsJson == null || deleteIdsJson.isEmpty() ? "[]" : deleteIdsJson);
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        synchronized (PsmCloudSyncWorker.class) {
            JSONObject pending = new JSONObject(prefs.getString(KEY_QUEUE, "{}"));
            JSONArray mergedRecords = mergeRecords(pending.optJSONArray("records"), incomingRecords);
            JSONArray mergedDeletes = mergeIds(pending.optJSONArray("deleteIds"), incomingDeletes);
            // Penghapusan selalu menang atas antrean upload untuk ID yang sama.
            mergedRecords = removeDeletedRecords(mergedRecords, mergedDeletes);
            payload.put("url", url);
            payload.put("records", mergedRecords);
            payload.put("deleteIds", mergedDeletes);
            prefs.edit().putString(KEY_QUEUE, payload.toString()).apply();
        }
        Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(PsmCloudSyncWorker.class)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build();
        WorkManager.getInstance(context).enqueueUniqueWork("psm-cloud-sync", ExistingWorkPolicy.KEEP, request);
    }

    @NonNull @Override public Result doWork() {
        SharedPreferences prefs = getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String snapshot = prefs.getString(KEY_QUEUE, null);
        if (snapshot == null || snapshot.isEmpty()) return Result.success();
        try {
            JSONObject job = new JSONObject(snapshot);
            String endpoint = job.getString("url");
            JSONArray records = job.optJSONArray("records"); if (records == null) records = new JSONArray();
            JSONArray deleteIds = job.optJSONArray("deleteIds"); if (deleteIds == null) deleteIds = new JSONArray();

            if (records.length() > 0) {
                post(endpoint, records.toString());
                JSONArray cloud = fetchRows(endpoint);
                for (int i = 0; i < records.length(); i++) {
                    String id = records.getJSONObject(i).optString("id", "");
                    if (!containsId(cloud, id)) throw new Exception("Cloud belum mengonfirmasi ID transaksi " + id);
                }
            }
            if (deleteIds.length() > 0) {
                JSONObject del = new JSONObject(); del.put("action", "delete"); del.put("ids", deleteIds);
                post(endpoint, del.toString());
                JSONArray cloud = fetchRows(endpoint);
                for (int i = 0; i < deleteIds.length(); i++) {
                    if (containsId(cloud, deleteIds.optString(i))) throw new Exception("Cloud belum mengonfirmasi penghapusan");
                }
            }
            // Hapus hanya ID yang worker ini sudah verifikasi. Antrean baru tetap utuh.
            synchronized (PsmCloudSyncWorker.class) {
                String latest = prefs.getString(KEY_QUEUE, null);
                if (latest != null) {
                    JSONObject current = new JSONObject(latest);
                    JSONArray remainingRecords = removeProcessedRecords(current.optJSONArray("records"), records);
                    JSONArray remainingDeletes = removeProcessedIds(current.optJSONArray("deleteIds"), deleteIds);
                    if (remainingRecords.length() == 0 && remainingDeletes.length() == 0) {
                        prefs.edit().remove(KEY_QUEUE).apply();
                    } else {
                        current.put("records", remainingRecords);
                        current.put("deleteIds", remainingDeletes);
                        prefs.edit().putString(KEY_QUEUE, current.toString()).apply();
                        return Result.retry();
                    }
                }
            }
            return Result.success();
        } catch (Exception e) {
            Log.w(TAG, "Sinkronisasi latar belakang akan dicoba ulang", e);
            return Result.retry();
        }
    }

    private static JSONArray mergeRecords(JSONArray oldRows, JSONArray newRows) throws Exception {
        java.util.LinkedHashMap<String, JSONObject> byId = new java.util.LinkedHashMap<>();
        if (oldRows != null) for (int i=0;i<oldRows.length();i++) { JSONObject o=oldRows.optJSONObject(i); if(o!=null) byId.put(o.optString("id", ""), o); }
        if (newRows != null) for (int i=0;i<newRows.length();i++) { JSONObject o=newRows.optJSONObject(i); if(o!=null) byId.put(o.optString("id", ""), o); }
        JSONArray out = new JSONArray(); for (JSONObject o : byId.values()) if (!o.optString("id", "").isEmpty()) out.put(o); return out;
    }
    private static JSONArray mergeIds(JSONArray oldIds, JSONArray newIds) {
        java.util.LinkedHashSet<String> ids = new java.util.LinkedHashSet<>();
        if(oldIds!=null) for(int i=0;i<oldIds.length();i++) { String id=oldIds.optString(i, ""); if(!id.isEmpty()) ids.add(id); }
        if(newIds!=null) for(int i=0;i<newIds.length();i++) { String id=newIds.optString(i, ""); if(!id.isEmpty()) ids.add(id); }
        JSONArray out=new JSONArray(); for(String id:ids) out.put(id); return out;
    }
    private static JSONArray removeDeletedRecords(JSONArray rows, JSONArray deletes) {
        java.util.HashSet<String> ids=new java.util.HashSet<>(); if(deletes!=null) for(int i=0;i<deletes.length();i++) ids.add(deletes.optString(i, ""));
        JSONArray out=new JSONArray(); if(rows!=null) for(int i=0;i<rows.length();i++){ JSONObject o=rows.optJSONObject(i); if(o!=null && !ids.contains(o.optString("id", ""))) out.put(o); } return out;
    }
    private static JSONArray removeProcessedRecords(JSONArray current, JSONArray processed) throws Exception {
        java.util.HashMap<String,String> done=new java.util.HashMap<>();
        if(processed!=null) for(int i=0;i<processed.length();i++){ JSONObject o=processed.optJSONObject(i); if(o!=null) done.put(o.optString("id", ""), o.toString()); }
        JSONArray out=new JSONArray(); if(current!=null) for(int i=0;i<current.length();i++){ JSONObject o=current.optJSONObject(i); if(o!=null && !o.toString().equals(done.get(o.optString("id", "")))) out.put(o); } return out;
    }
    private static JSONArray removeProcessedIds(JSONArray current, JSONArray processed) {
        java.util.HashSet<String> done=new java.util.HashSet<>(); if(processed!=null) for(int i=0;i<processed.length();i++) done.add(processed.optString(i, ""));
        JSONArray out=new JSONArray(); if(current!=null) for(int i=0;i<current.length();i++){ String id=current.optString(i, ""); if(!done.contains(id)) out.put(id); } return out;
    }

    private static void post(String endpoint, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(20000); c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(false);
        c.setRequestProperty("Content-Type", "text/plain;charset=utf-8");
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream out = c.getOutputStream()) { out.write(bytes); }
        int code = c.getResponseCode();
        // Apps Script Web App umumnya merespons dengan redirect setelah doPost dieksekusi.
        if (code != 200 && code != 201 && code != 202 && code != 302 && code != 303) {
            throw new Exception("POST Cloud gagal, HTTP " + code);
        }
        c.disconnect();
    }

    private static JSONArray fetchRows(String endpoint) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("GET"); c.setConnectTimeout(20000); c.setReadTimeout(30000); c.setUseCaches(false);
        int code = c.getResponseCode(); if (code < 200 || code >= 300) throw new Exception("GET Cloud gagal, HTTP " + code);
        StringBuilder b = new StringBuilder();
        try (InputStream in = c.getInputStream(); BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line; while ((line = r.readLine()) != null) b.append(line);
        } finally { c.disconnect(); }
        Object parsed = new org.json.JSONTokener(b.toString()).nextValue();
        if (parsed instanceof JSONArray) return (JSONArray) parsed;
        if (parsed instanceof JSONObject) {
            JSONArray data = ((JSONObject) parsed).optJSONArray("data");
            if (data != null) return data;
        }
        throw new Exception("Format data Cloud tidak dikenali");
    }

    private static boolean containsId(JSONArray rows, String id) throws Exception {
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row != null && id.equals(row.optString("id", ""))) return true;
        }
        return false;
    }
}
`;
fs.writeFileSync(path.join(javaDir, 'PsmCloudSyncWorker.java'), worker);
console.log('WorkManager dependency dan PsmCloudSyncWorker berhasil dipasang.');
