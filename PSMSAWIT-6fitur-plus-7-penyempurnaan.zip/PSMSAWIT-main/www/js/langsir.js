/* PSM SAWIT - Rekap Ongkos Langsir (menu mandiri, tidak mengubah transaksi timbang) */
const PSM_LANGSIR_PAYMENTS_KEY = 'psm_langsir_payment_records_v1';
let psmLangsirCurrent = null;
let psmLangsirSelectedDrivers = new Set();

function openLangsirRecap() {
    const host = document.getElementById('langsir-modal');
    if (!host) return;
    const drivers = [...new Set((db || []).map(x => String(x.driver || '').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'id'));
    psmLangsirSelectedDrivers = new Set();
    const today = new Date();
    const iso = d => new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10);
    document.getElementById('langsir-start').value = iso(new Date(today.getFullYear(), today.getMonth(), 1));
    document.getElementById('langsir-end').value = iso(today);
    const list = document.getElementById('langsir-driver-options');
    list.innerHTML = drivers.length ? drivers.map((name,i)=>`<label class="langsir-driver-option"><input type="checkbox" value="${escapeLangsirHtml(name)}" onchange="toggleLangsirDriver(this)"><span>${escapeLangsirHtml(name)}</span></label>`).join('') : '<p class="langsir-muted">Belum ada nama sopir pada transaksi.</p>';
    document.getElementById('langsir-select-all').checked = false;
    document.getElementById('langsir-result-step').style.display = 'none';
    document.getElementById('langsir-filter-step').style.display = 'block';
    host.style.display = 'flex';
}
function closeLangsirRecap(){ const el=document.getElementById('langsir-modal'); if(el) el.style.display='none'; }
function escapeLangsirHtml(v){ return String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function toggleLangsirDriver(el){ if(el.checked) psmLangsirSelectedDrivers.add(el.value); else psmLangsirSelectedDrivers.delete(el.value); }
function toggleAllLangsirDrivers(el){ document.querySelectorAll('#langsir-driver-options input[type=checkbox]').forEach(cb=>{cb.checked=el.checked; if(el.checked) psmLangsirSelectedDrivers.add(cb.value); else psmLangsirSelectedDrivers.delete(cb.value);}); }
function buildLangsirReport(){
    const start=document.getElementById('langsir-start').value, end=document.getElementById('langsir-end').value;
    if(!start || !end || start>end){alert('Tanggal awal dan akhir belum benar.');return;}
    const drivers=[...psmLangsirSelectedDrivers]; if(!drivers.length){alert('Pilih minimal satu sopir/pelangsir.');return;}
    const selected=(db||[]).filter(x=>drivers.includes(String(x.driver||'').trim()) && String(x.date||'').slice(0,10)>=start && String(x.date||'').slice(0,10)<=end);
    const reports=drivers.map(driver=>{
        const rows=selected.filter(x=>String(x.driver||'').trim()===driver);
        const groups={};
        rows.forEach(x=>{
            const owner=String(x.owner||'-').trim()||'-';
            const net=Number(x.n1 ?? (Number(x.w1||0)-Number(x.w2||0)))||0;
            const rate=Number(x.fl||0)||0;
            // Gunakan nilai ongkos transaksi yang tersimpan sebagai sumber utama.
            const amount=Number.isFinite(Number(x.tL)) ? Number(x.tL) : Math.round(net*rate);
            if(!groups[owner]) groups[owner]={owner,net:0,amount:0,count:0,rows:[],rates:{}};
            groups[owner].net+=net; groups[owner].amount+=amount; groups[owner].count++; groups[owner].rows.push(x);
            const rateKey=String(rate);
            if(!groups[owner].rates[rateKey]) groups[owner].rates[rateKey]={rate,net:0,amount:0};
            groups[owner].rates[rateKey].net+=net;
            groups[owner].rates[rateKey].amount+=amount;
        });
        const owners=Object.values(groups).map(o=>({...o,rateBreakdown:Object.values(o.rates).sort((a,b)=>a.rate-b.rate)})).sort((a,b)=>a.owner.localeCompare(b.owner,'id'));
        return {driver,owners,net:owners.reduce((s,x)=>s+x.net,0),gross:owners.reduce((s,x)=>s+x.amount,0),deductions:[],deductionTotal:0,netPay:owners.reduce((s,x)=>s+x.amount,0),count:rows.length};
    });
    psmLangsirCurrent={start,end,reports};
    renderLangsirReport();
    document.getElementById('langsir-filter-step').style.display='none';
    document.getElementById('langsir-result-step').style.display='block';
}
function renderLangsirReport(){
    const host=document.getElementById('langsir-report-result'); if(!host||!psmLangsirCurrent)return;
    const grandGross=psmLangsirCurrent.reports.reduce((s,r)=>s+r.gross,0);
    const grandNet=psmLangsirCurrent.reports.reduce((s,r)=>s+r.net,0);
    host.innerHTML=psmLangsirCurrent.reports.map((r,i)=>`<section class="langsir-driver-report">
      <div class="langsir-report-head"><div><b>${escapeLangsirHtml(r.driver)}</b><small>${r.count} transaksi · ${escapeLangsirHtml(psmLangsirCurrent.start)} s/d ${escapeLangsirHtml(psmLangsirCurrent.end)}</small></div><b>${formatLangsirRp(r.gross)}</b></div>
      <div class="langsir-owner-breakdowns">${r.owners.map(o=>`<div class="langsir-owner-card"><b>${escapeLangsirHtml(o.owner)}</b>${o.rateBreakdown.map(q=>`<div class="langsir-rate-line"><span>${formatLangsirNum(q.net)} kg × ${formatLangsirRp(q.rate)}</span><strong>${formatLangsirRp(q.amount)}</strong></div>`).join('')}<div class="langsir-owner-total"><span>Total netto ${formatLangsirNum(o.net)} kg</span><strong>${formatLangsirRp(o.amount)}</strong></div></div>`).join('')||'<p class="langsir-muted">Tidak ada transaksi pada periode ini.</p>'}</div>
      <div class="langsir-driver-totals"><div><span>Total netto</span><b>${formatLangsirNum(r.net)} kg</b></div><div><span>Total ongkos langsir</span><b>${formatLangsirRp(r.gross)}</b></div></div>
      <div class="langsir-deduction-area"><b>Potongan tambahan — ${escapeLangsirHtml(r.driver)}</b><div id="langsir-deduction-list-${i}">${renderLangsirDeductions(r,i)}</div><button type="button" class="langsir-secondary" onclick="addLangsirDeduction(${i})">＋ Tambah potongan</button></div>
      <div class="langsir-netpay">Pembayaran bersih <strong id="langsir-netpay-${i}">${formatLangsirRp(r.netPay)}</strong></div>
      <div class="langsir-footer-actions"><button type="button" class="langsir-secondary" onclick="previewLangsirImage(${i})">PRATINJAU GAMBAR</button><button type="button" class="langsir-secondary" onclick="printLangsirThermal(${i})">CETAK THERMAL</button></div>
      <button type="button" class="langsir-primary" onclick="saveLangsirPayment(${i})">SIMPAN REKAP PEMBAYARAN SOPIR INI</button>
    </section>`).join('')+`<div class="langsir-grand-total"><small>Total semua sopir terpilih</small><strong>${formatLangsirRp(grandGross)}</strong><small>Netto keseluruhan: ${formatLangsirNum(grandNet)} kg. Pembayaran tetap terpisah per sopir.</small></div>`;
}
function formatLangsirNum(n){return Math.round(Number(n)||0).toLocaleString('id-ID');}
function formatLangsirRp(n){return 'Rp '+formatLangsirNum(n);}
function renderLangsirDeductions(r,i){return r.deductions.map((d,j)=>`<div class="langsir-deduction-row"><input aria-label="Keterangan potongan" placeholder="Kasbon / BBM" value="${escapeLangsirHtml(d.label)}" oninput="updateLangsirDeduction(${i},${j},'label',this.value)"><input aria-label="Nominal potongan" type="number" min="0" inputmode="numeric" placeholder="Nominal Rp" value="${Number(d.amount)||''}" oninput="updateLangsirDeduction(${i},${j},'amount',this.value)"><button type="button" onclick="removeLangsirDeduction(${i},${j})" aria-label="Hapus potongan">×</button></div>`).join('');}
function refreshLangsirDeductions(i){const r=psmLangsirCurrent.reports[i];r.deductionTotal=r.deductions.reduce((s,d)=>s+(Math.max(0,Number(d.amount)||0)),0);r.netPay=r.gross-r.deductionTotal;const list=document.getElementById(`langsir-deduction-list-${i}`);if(list)list.innerHTML=renderLangsirDeductions(r,i);const total=document.getElementById(`langsir-netpay-${i}`);if(total)total.textContent=formatLangsirRp(r.netPay);}
function addLangsirDeduction(i){psmLangsirCurrent.reports[i].deductions.push({label:'',amount:0});refreshLangsirDeductions(i);}
function updateLangsirDeduction(i,j,key,value){const d=psmLangsirCurrent.reports[i].deductions[j];d[key]=key==='amount'?Math.max(0,Number(value)||0):value;const total=document.getElementById(`langsir-netpay-${i}`);const r=psmLangsirCurrent.reports[i];r.deductionTotal=r.deductions.reduce((s,x)=>s+Math.max(0,Number(x.amount)||0),0);r.netPay=r.gross-r.deductionTotal;if(total)total.textContent=formatLangsirRp(r.netPay);}
function removeLangsirDeduction(i,j){psmLangsirCurrent.reports[i].deductions.splice(j,1);refreshLangsirDeductions(i);}
function saveLangsirPayment(i){
    const r=psmLangsirCurrent && psmLangsirCurrent.reports[i];if(!r)return;
    if(r.netPay<0){alert('Total potongan melebihi ongkos langsir. Periksa kembali.');return;}
    const records=JSON.parse(localStorage.getItem(PSM_LANGSIR_PAYMENTS_KEY)||'[]');
    const rec={id:'LGS-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),createdAt:new Date().toISOString(),start:psmLangsirCurrent.start,end:psmLangsirCurrent.end,driver:r.driver,owners:r.owners.map(o=>({owner:o.owner,net:o.net,amount:o.amount,count:o.count,rateBreakdown:o.rateBreakdown.map(q=>({...q}))})),net:r.net,gross:r.gross,deductions:r.deductions.map(d=>({...d})),deductionTotal:r.deductionTotal,netPay:r.netPay,transactionCount:r.count};
    records.push(rec);localStorage.setItem(PSM_LANGSIR_PAYMENTS_KEY,JSON.stringify(records));
    alert(`Rekap pembayaran ${r.driver} tersimpan. Pembayaran bersih ${formatLangsirRp(r.netPay)}.`);
}


function buildLangsirReceiptHtml(r){
    const settingsLogo=(typeof isNotaLogoImageEnabled==='function' && isNotaLogoImageEnabled() && typeof getNotaLogoSrc==='function') ? `<img class="langsir-receipt-logo" src="${getNotaLogoSrc()}" alt="Logo nota">` : '';
    const ownerHtml=r.owners.map(o=>`<section class="langsir-receipt-owner"><b>${escapeLangsirHtml(o.owner)}</b>${o.rateBreakdown.map(q=>`<div class="langsir-receipt-rate"><span>${formatLangsirNum(q.net)} kg × ${formatLangsirRp(q.rate)}</span><b>${formatLangsirRp(q.amount)}</b></div>`).join('')}<div class="langsir-receipt-owner-total"><span>Total pemilik</span><b>${formatLangsirRp(o.amount)}</b></div></section>`).join('');
    const cuts=r.deductions.filter(d=>(String(d.label||'').trim() || Number(d.amount)>0));
    return `<article class="langsir-receipt">${settingsLogo}<h2>REKAP ONGKOS LANGSIR</h2><div class="langsir-receipt-meta">SOPIR: ${escapeLangsirHtml(r.driver)}<br>PERIODE: ${escapeLangsirHtml(psmLangsirCurrent.start)} s/d ${escapeLangsirHtml(psmLangsirCurrent.end)}</div><hr>${ownerHtml}<hr><div class="langsir-receipt-total"><span>TOTAL ONGKOS LANGSIR</span><b>${formatLangsirRp(r.gross)}</b></div><hr><b>POTONGAN</b>${cuts.map(d=>`<div class="langsir-receipt-cut"><span>${escapeLangsirHtml(d.label||'Potongan')}</span><b>${formatLangsirRp(d.amount)}</b></div>`).join('')||'<div class="langsir-receipt-cut"><span>Tidak ada</span><b>Rp 0</b></div>'}<div class="langsir-receipt-cut langsir-cut-total"><span>Total potongan</span><b>${formatLangsirRp(r.deductionTotal)}</b></div><hr><div class="langsir-receipt-net"><span>BERSIH DIBAYARKAN</span><b>${formatLangsirRp(r.netPay)}</b></div></article>`;
}
function previewLangsirImage(i){
    const r=psmLangsirCurrent && psmLangsirCurrent.reports[i]; if(!r)return;
    let modal=document.getElementById('langsir-image-preview');
    if(!modal){modal=document.createElement('div');modal.id='langsir-image-preview';modal.className='langsir-preview-overlay';modal.innerHTML='<div class="langsir-preview-panel"><div class="langsir-preview-actions"><b>Pratinjau gambar rekap</b><button type="button" onclick="closeLangsirImagePreview()">TUTUP</button></div><div id="langsir-image-content"></div><button type="button" class="langsir-primary" onclick="downloadLangsirImage()">SIMPAN GAMBAR</button></div>';document.body.appendChild(modal);}
    document.getElementById('langsir-image-content').innerHTML=buildLangsirReceiptHtml(r); modal.dataset.reportIndex=String(i); modal.style.display='flex';
}
function closeLangsirImagePreview(){const m=document.getElementById('langsir-image-preview');if(m)m.style.display='none';}
async function downloadLangsirImage(){
    const node=document.querySelector('#langsir-image-content .langsir-receipt'); if(!node){alert('Pratinjau belum tersedia.');return;}
    const clone=node.cloneNode(true); clone.style.width='360px'; clone.style.padding='18px'; clone.style.background='#fff'; clone.style.color='#111';
    const html=new XMLSerializer().serializeToString(clone);
    const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="396" height="1800"><foreignObject width="100%" height="100%"><div xmlns="http://www.w3.org/1999/xhtml">${html}</div></foreignObject></svg>`;
    const blob=new Blob([svg],{type:'image/svg+xml;charset=utf-8'}); const url=URL.createObjectURL(blob);
    try{
        const img=new Image(); await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=url;});
        const canvas=document.createElement('canvas');canvas.width=396;canvas.height=Math.min(1800,Math.max(500,Math.ceil(node.scrollHeight*1.1)));
        const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
        const a=document.createElement('a');a.href=canvas.toDataURL('image/png');a.download='rekap-ongkos-langsir.png';a.click();
    }catch(e){alert('Gambar belum dapat dibuat pada perangkat ini. Silakan gunakan tangkapan layar pratinjau.');}
    finally{URL.revokeObjectURL(url);}
}
function buildLangsirThermalText(r){
    const line='--------------------------------'; let t='';
    t+='\x1B\x61\x01\x1B\x45\x01REKAP ONGKOS LANGSIR\x1B\x45\x00\n';
    t+='\x1B\x61\x00'+line+'\n';
    t+='Sopir : '+safeText(r.driver)+'\n';
    t+='Periode : '+safeText(psmLangsirCurrent.start)+' s/d\n          '+safeText(psmLangsirCurrent.end)+'\n'+line+'\n';
    r.owners.forEach(o=>{
        t+='\x1B\x45\x01'+safeText(o.owner)+'\x1B\x45\x00\n';
        o.rateBreakdown.forEach(q=>{
            t+=formatLangsirNum(q.net)+'kg x '+formatLangsirRp(q.rate)+'\n';
            t+='= '+formatLangsirRp(q.amount)+'\n';
        });
        t+='\n';
    });
    t+=line+'\n\x1B\x45\x01TOTAL ONGKOS LANGSIR\n'+formatLangsirRp(r.gross)+'\x1B\x45\x00\n'+line+'\n';
    t+='POTONGAN\n';
    const cuts=r.deductions.filter(d=>(String(d.label||'').trim() || Number(d.amount)>0));
    if(!cuts.length)t+='Tidak ada : Rp 0\n';
    cuts.forEach(d=>{t+=safeText(d.label||'Potongan')+'\n  '+formatLangsirRp(d.amount)+'\n';});
    t+='Total potongan : '+formatLangsirRp(r.deductionTotal)+'\n'+line+'\n';
    t+='\x1B\x45\x01BERSIH DIBAYARKAN\n'+formatLangsirRp(r.netPay)+'\x1B\x45\x00\n';
    t+='\x1B\x61\x01Terima kasih\n\x1B\x61\x00\n\n\n';
    return t;
}
async function printLangsirThermal(i){
    const r=psmLangsirCurrent && psmLangsirCurrent.reports[i]; if(!r)return;
    if(typeof __psmPrintRunning!=='undefined' && __psmPrintRunning){alert('Printer sedang digunakan. Coba sebentar lagi.');return;}
    if(typeof beepClick==='function')beepClick();
    if(typeof __psmPrintRunning!=='undefined')__psmPrintRunning=true;
    try{
        const text=buildLangsirThermalText(r);
        const useLogo=typeof isThermalLogoBitmapEnabled==='function' && isThermalLogoBitmapEnabled();
        if(useLogo && window.NativeBridge && typeof window.NativeBridge.printRawBTBase64Bytes==='function' && typeof buildThermalLogoRasterBytes==='function'){
            const packed=bytesToBase64((await buildThermalLogoRasterBytes()).concat(textToThermalBytes(text)));
            const ok=await window.NativeBridge.printRawBTBase64Bytes(packed); if(ok)return;
        }
        if(window.NativeBridge && typeof window.NativeBridge.printRawBT==='function'){const ok=await window.NativeBridge.printRawBT(text);if(ok)return;}
        if(window.AndroidRawBT && typeof window.AndroidRawBT.print==='function'){window.AndroidRawBT.print(text);return;}
        window.location.href='intent:'+encodeURIComponent(text)+'#Intent;scheme=rawbt;package=ru.a402d.rawbtprinter;end;';
    }catch(e){console.error('Cetak rekap langsir gagal',e);alert('Cetak thermal gagal: '+(e.message||e));}
    finally{if(typeof __psmPrintRunning!=='undefined')setTimeout(()=>{__psmPrintRunning=false;},1200);}
}

