// ===============================
// PSM SAWIT - table.js
// Versi FIX MONITORING: cloud dekat nomor, ongkos terlihat, urutan edit tidak berubah.
// ===============================

function updateLists() {
    let o = new Set(savedOwners), d = new Set(savedDrivers);
    db.forEach(x => { if(x.owner) o.add(x.owner); if(x.driver) d.add(x.driver); });
    savedOwners = [...o].filter(Boolean).map(x => String(x).toUpperCase().trim()).filter(Boolean).sort();
    savedDrivers = [...d].filter(Boolean).map(x => String(x).toUpperCase().trim()).filter(Boolean).sort();
    localStorage.setItem('psm_owners', JSON.stringify(savedOwners));
    localStorage.setItem('psm_drivers', JSON.stringify(savedDrivers));
    if (typeof closeAllPsmNameLists === 'function') closeAllPsmNameLists();
}

function fillTarif() {
    if (curIdx !== -1) return;
    let n = document.getElementById('in-owner').value.toUpperCase().trim();
    if(mem[n]) {
        document.getElementById('in-fl').value = mem[n].l || 0;
        document.getElementById('in-fj').value = mem[n].j || 0;
        document.getElementById('in-fp').value = mem[n].p || 0;
    }
}

function clearSelection() {
    selectedIds.clear();
    const all = document.getElementById('chk-all');
    if (all) all.checked = false;
    document.querySelectorAll('.row-chk').forEach(cb => cb.checked = false);
}

function toggleRow(id, cb) {
    beepClick();
    const safeId = normalizeId(id);
    if(cb && cb.checked) selectedIds.add(safeId); else selectedIds.delete(safeId);
    const all = document.getElementById('chk-all');
    if(cb && !cb.checked && all) all.checked = false;
}

function toggleAll(cb) {
    beepClick();
    let checkboxes = document.querySelectorAll('.row-chk');
    checkboxes.forEach(c => {
        c.checked = cb.checked;
        const safeId = normalizeId(c.value);
        if(cb.checked) selectedIds.add(safeId);
        else selectedIds.delete(safeId);
    });
}

function debounceSearch(cb) {
    clearTimeout(window.tSearch);
    window.tSearch = setTimeout(cb, 300);
}

let psmTablePage = 1;
let psmLastFilterKey = '';
function loadMoreLiveRows() { psmTablePage++; renderLiveTable(); }
function renderLiveTable() {
    const idEl = document.getElementById('f-id');
    let qid = idEl ? String(idEl.value || '').trim().toUpperCase() : '';
    let n = document.getElementById('f-name').value.toUpperCase().trim();
    let d = document.getElementById('f-driver').value.toUpperCase().trim();
    let s = document.getElementById('f-start').value, e = document.getElementById('f-end').value;
    const isFiltered = !!(qid || n || d || s || e);
    const filterKey = [qid,n,d,s,e].join('|');
    if (filterKey !== psmLastFilterKey) { psmLastFilterKey = filterKey; psmTablePage = 1; }
    // Satu pemetaan ID menghindari findIndex berulang pada ribuan transaksi.
    const indexById = new Map();
    for (let i = 0; i < db.length; i++) indexById.set(normalizeId(db[i] && db[i].id), i);
    let filtered = [];
    for (const x of db) {
        if (!x) continue;
        if (qid && !String(x.id || '').toUpperCase().includes(qid) && !String(indexById.get(normalizeId(x.id)) + 1).includes(qid)) continue;
        if (n && !(x.owner && x.owner.includes(n))) continue;
        if (d && !(x.driver && x.driver.includes(d))) continue;
        if (s && String(x.date || '') < s) continue;
        if (e && String(x.date || '') > e) continue;
        filtered.push(x);
    }
    // Pertahankan urutan input. Tanpa filter, tampilkan 150 data terbaru agar DOM tetap ringan.
    const pageSize = isFiltered ? 250 : 150;
    const displayData = isFiltered ? filtered.slice(-pageSize * psmTablePage) : filtered.slice(-150);
    let body = '';
    const all = document.getElementById('chk-all');
    if (all) all.checked = false;
    for (let j = displayData.length - 1; j >= 0; j--) {
        const x = displayData[j];
        const idx = indexById.get(normalizeId(x.id));
        const id = normalizeId(x.id);
        const isChecked = selectedIds.has(id) ? 'checked' : '';
        const awan = x.synced ? '✅' : '☁️';
        body += `<tr class="${idx === curIdx ? 'active-row' : ''}">
            <td align="center"><input type="checkbox" class="row-chk" value="${escapeHtml(id)}" ${isChecked} onchange="toggleRow(this.value, this)"></td>
            <td align="center" onclick="editH(${idx})">${idx + 1}</td>
            <td align="center" title="Status cloud" onclick="editH(${idx})">${awan}</td>
            <td align="center" onclick="editH(${idx})">${fTgl(x.date)}</td>
            <td onclick="editH(${idx})"><b>${escapeHtml(x.owner)}</b></td>
            <td onclick="editH(${idx})">${escapeHtml(x.driver)}</td>
            <td align="right" onclick="editH(${idx})">${fNum(x.w1)}</td>
            <td align="right" onclick="editH(${idx})">${fNum(x.w2)}</td>
            <td align="right" onclick="editH(${idx})">${Math.round(x.n1)}</td>
            <td align="right" style="color:#2563eb; font-weight:bold" onclick="editH(${idx})"><b>${(x.n2||0).toFixed(2)}</b></td>
            <td align="right" onclick="editH(${idx})">${fNum(x.price)}</td>
            <td align="right" onclick="editH(${idx})">${fNum(x.kotor)}</td>
            <td align="right" style="font-weight:bold; color:#059669" onclick="editH(${idx})">${fNum(x.bersih)}</td>
            <td align="right" onclick="editH(${idx})">${fNum(x.fl || 0)}</td>
            <td align="right" onclick="editH(${idx})">${fNum(x.fj || 0)}</td>
            <td align="right" onclick="editH(${idx})">${fNum(x.fp || 0)}</td>
        </tr>`;
    }
    const bodyEl = document.getElementById('live-body');
    if (bodyEl) {
        bodyEl.innerHTML = body || '<tr><td colspan="16" align="center">Kosong</td></tr>';
        const oldMore = document.getElementById('psm-load-more-row'); if (oldMore) oldMore.remove();
        if (isFiltered && displayData.length < filtered.length) {
            const tr = document.createElement('tr'); tr.id = 'psm-load-more-row';
            tr.innerHTML = `<td colspan="16" style="text-align:center;padding:12px"><button type="button" onclick="loadMoreLiveRows()" style="padding:9px 16px;border:0;border-radius:8px;background:#334155;color:white;font-weight:700">TAMPILKAN 250 DATA LAGI (${filtered.length-displayData.length} tersisa)</button></td>`;
            bodyEl.appendChild(tr);
        }
    }
    if (typeof psmSetPendingSyncIndicator === 'function') psmSetPendingSyncIndicator();
}
