const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={
  db:[{id:'A1',date:'2026-11-05',time:'08:15',owner:'OWNER A',driver:'DRIVER X',w1:8500,w2:2000,synced:true}],
  normalizeId:x=>String(x||'').trim(), fNum:x=>String(x),
  confirm:()=>true, alert:()=>{}, console, Date, Math, Number, String, Array, Set,
  window:{addEventListener:()=>{},isSyncing:false}, document:{getElementById:()=>null},
  getPendingDeleteIds:()=>[]
};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('www/js/enhancements.js','utf8'),ctx);
assert.equal(vm.runInContext("psmDuplicateCandidates({date:'2026-11-05',time:'08:15',owner:'owner a',driver:'driver x',w1:8500,w2:2000},null).length",ctx),1);
assert.equal(vm.runInContext("psmDuplicateCandidates({date:'2026-11-05',time:'08:15',owner:'owner a',driver:'driver x',w1:8501,w2:2000},null).length",ctx),0);
assert.equal(vm.runInContext("psmValidateWeightInputs(8500,2000)",ctx),'');
assert.ok(vm.runInContext("psmValidateWeightInputs(1000,2000)",ctx));
assert.ok(vm.runInContext("psmValidateWeightInputs(0,0)",ctx));
console.log('ENHANCEMENT_UNIT_TESTS_PASS');
