# PSM SAWIT Admin v1.44.2 — Status Pemeriksaan

## Status
Paket ini telah melewati pemeriksaan otomatis yang tersedia di dalam source. Status ini TIDAK berarti bebas dari semua bug atau sudah teruji pada semua perangkat.

## Pemeriksaan yang dijalankan pada paket ini
- `npm test` / `npm run test:all`: lulus.
- `node scripts/verify-package.js`: lulus.
- Tes enhancement dan regresi keamanan data: lulus.
- Tes reliabilitas, CSV 10.000 baris, parser ACK RAWBT, backup multiline, kegagalan storage, persistensi sync, rollback antrean hapus, native failure ACK: lulus.
- Tes filter periode ongkos langsir: lulus.
- Pemeriksaan sintaks JavaScript/CJS: lulus melalui self-check paket dan skrip tes.

## Belum dapat dibuktikan tanpa perangkat/layanan nyata
1. Ketahanan saat HP kehabisan ruang, mati mendadak, atau Android menghentikan proses saat transaksi disimpan.
2. Kompatibilitas semua versi Android/WebView dan berbagai ukuran layar.
3. Cetak fisik pada setiap model printer Bluetooth/RAWBT.
4. Sinkronisasi dengan endpoint Cloud produksi, jaringan putus-sambung, dan konflik antarperangkat.
5. Pemulihan backup pada perangkat berbeda dan skenario database sangat besar.

## Cara menjalankan pemeriksaan
Jalankan `npm test` dari folder proyek. Perintah ini menjalankan seluruh tes otomatis yang tersedia.

## Catatan penggunaan aman
Sebelum mengganti APK yang sedang dipakai, ekspor backup dari aplikasi lama dan simpan salinannya di luar HP. Uji APK baru menggunakan salinan data terlebih dahulu. Jangan menghapus APK/data lama sampai hasil uji transaksi, cetak, backup/restore, dan Cloud dinyatakan benar.

Tidak ada klaim perangkat lunak bebas bug 100%. Pemeriksaan otomatis hanya mencakup skenario yang ditulis dalam tes.
