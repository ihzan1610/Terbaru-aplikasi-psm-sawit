const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const source = fs.readFileSync('www/js/langsir.js', 'utf8');
const elements = {
  'langsir-start': { value: '2026-11-01' },
  'langsir-end': { value: '2026-11-06' },
  'langsir-driver-search': { value: '' },
  'langsir-driver-options': { innerHTML: '' },
  'langsir-select-all': { checked: false, indeterminate: false },
  'langsir-filter-step': { style: {} },
  'langsir-result-step': { style: {} },
  'langsir-modal': { style: {} },
  'langsir-report-result': { innerHTML: '' }
};
const context = {
  db: [
    { id: 'A1', date: '2026-11-02', driver: 'SUPIR AKTIF', owner: 'A', n1: 8000, fl: 50, tL: 400000 },
    { id: 'A2', date: '2026-11-05', driver: 'SUPIR AKTIF', owner: 'B', n1: 5000, fl: 40, tL: 200000 },
    { id: 'B1', date: '2026-10-31', driver: 'SUPIR DI LUAR PERIODE', fl: 50, tL: 100000 },
    { id: 'C1', date: '2026-11-03', driver: 'SUPIR TANPA ONGKOS', fl: 0, tL: 0 },
    { id: 'D1', date: '2026-11-07', driver: 'SUPIR SETELAH PERIODE', fl: 50, tL: 100000 },
    { id: 'E1', date: '2026-11-04', driver: '  SUPIR TRIM  ', fl: 10, tL: 10000 }
  ],
  document: { getElementById: id => elements[id] || null },
  getComputedStyle: () => ({ display: 'none' }),
  alert: msg => { context.lastAlert = msg; },
  console, Date, String, Number, Math, Set, Array, Object, JSON,
  formatLangsirRp: n => String(n), formatLangsirNum: n => String(n)
};
vm.createContext(context);
vm.runInContext(source, context);

assert.deepStrictEqual(Array.from(vm.runInContext("getLangsirPeriodDriverNames('2026-11-01','2026-11-06')", context)), ['SUPIR AKTIF', 'SUPIR TRIM']);
vm.runInContext('filterLangsirDriversByPeriod()', context);
assert.match(elements['langsir-driver-options'].innerHTML, /SUPIR AKTIF/);
assert.match(elements['langsir-driver-options'].innerHTML, /SUPIR TRIM/);
assert.doesNotMatch(elements['langsir-driver-options'].innerHTML, /SUPIR DI LUAR PERIODE|SUPIR TANPA ONGKOS|SUPIR SETELAH PERIODE/);

// Changing the period must immediately refresh the list and discard stale selections.
vm.runInContext("psmLangsirSelectedDrivers = new Set(['SUPIR AKTIF', 'SUPIR DI LUAR PERIODE'])", context);
elements['langsir-start'].value = '2026-11-06';
elements['langsir-end'].value = '2026-11-06';
vm.runInContext('filterLangsirDriversByPeriod()', context);
assert.deepStrictEqual(Array.from(vm.runInContext('psmLangsirSelectedDrivers', context)), []);
assert.doesNotMatch(elements['langsir-driver-options'].innerHTML, /SUPIR AKTIF|SUPIR DI LUAR PERIODE/);

// Invalid/empty date window yields no names.
assert.strictEqual(vm.runInContext("getLangsirPeriodDriverNames('2026-11-07','2026-11-01').length", context), 0);
console.log('LANGSIR_PERIOD_DRIVER_FILTER_TESTS_PASS');
