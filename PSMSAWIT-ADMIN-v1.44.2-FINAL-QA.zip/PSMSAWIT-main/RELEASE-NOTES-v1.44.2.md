# PSM SAWIT v1.44.2 — Langsir Period Filter Fix

## Perbaikan
- Daftar sopir/pelangsir pada Rekap Ongkos Langsir hanya menampilkan sopir dengan transaksi berongkos langsir dalam rentang tanggal terpilih.
- Perubahan tanggal awal/akhir langsung menyegarkan daftar sopir.
- Pilihan sopir yang tidak lagi memiliki aktivitas pada periode yang baru dipilih otomatis dibersihkan.
- Validasi dilakukan kembali ketika tombol TAMPILKAN REKAP ditekan agar daftar lama tidak dapat menghasilkan rekap kosong atau keliru.
- Pesan yang jelas ditampilkan jika tidak ada aktivitas ongkos langsir pada periode tersebut.

## Kriteria aktivitas
Sopir dianggap memiliki aktivitas ongkos langsir jika ada transaksi pada periode yang dipilih dan nilai tarif `fl` lebih dari nol atau nilai ongkos tersimpan `tL` lebih dari nol.

## Pengujian
- Tes khusus filter periode langsir: lulus.
- Tes fitur lama dan keamanan data: lulus.
- Tes reliabilitas: lulus.
- Pemeriksaan sintaks seluruh JavaScript/CJS: lulus.
- Pemeriksaan kelengkapan paket: lulus.

Pengujian printer fisik, perangkat Android, dan Cloud produksi tetap memerlukan perangkat/layanan sebenarnya.
