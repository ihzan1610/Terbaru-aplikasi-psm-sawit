# PSM SAWIT v1.44.1 — Audit dan Perbaikan

Versi ini merupakan penyempurnaan lanjutan dari v1.44.0. Fokus utama adalah kejujuran status cetak, ketahanan backup CSV multiline, dan konsistensi penyimpanan/sinkronisasi.

Lihat `RELEASE-NOTES-v1.44.1.md`.

## Pemeriksaan lokal
```bash
find www/js scripts tests -type f \( -name "*.js" -o -name "*.cjs" \) -print0 | xargs -0 -n1 node --check
npm run test:all
node scripts/verify-package.js
```

## Build Android
Unggah isi proyek ke GitHub, jalankan workflow `Build Android Debug APK - PSM SAWIT FIX`, lalu unduh artifact `PSM-SAWIT-FIX-debug-apk`.
