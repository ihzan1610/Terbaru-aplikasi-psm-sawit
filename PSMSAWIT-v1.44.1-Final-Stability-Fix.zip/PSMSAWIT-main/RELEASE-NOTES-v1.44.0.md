# PSM SAWIT v1.44.0 — Reliability & Data Safety

## Perbaikan
- Native print, image-save, dan CSV-save hanya dianggap berhasil jika native mengembalikan konfirmasi `ok: true`.
- Respons native kosong, teks tidak terstruktur, `ok: false`, dan hasil bridge yang tidak terkonfirmasi ditolak.
- Printer yang sedang sibuk tidak lagi mengembalikan status sukses palsu.
- Tombol Back Android menutup panel Setelan Lanjutan sebelum menutup modal Pengaturan.
- Parser CSV menolak tanda kutip yang salah posisi, karakter setelah kutip penutup, dan CR tanpa LF.
- Penyimpanan transaksi dan antrean penghapusan mengembalikan status gagal bila seluruh media penyimpanan gagal serta memberi peringatan yang terlihat.
- Form transaksi menunggu konfirmasi penyimpanan; jika penyimpanan gagal, perubahan di memori dibatalkan.
- Restore menyimpan database terlebih dahulu dan hanya mengubah antrean penghapusan setelah database tersimpan; kegagalan antrean memicu pemulihan data lama.
- APK tidak lagi menyatakan file tersimpan hanya karena anchor download berhasil diklik; native save harus mengonfirmasi keberhasilan.

## Fitur yang dipertahankan
Tidak ada menu, field transaksi, rumus bisnis, tampilan, atau alur fitur lama yang sengaja dihapus. Perubahan difokuskan pada validasi hasil operasi, ketahanan penyimpanan, dan navigasi Back.

## Pengujian lokal
- `node --check` untuk seluruh JavaScript aplikasi, skrip build, dan tes.
- `npm run test:enhancements` — lulus.
- `npm run test:reliability` — menguji respons native gagal untuk cetak/simpan gambar/CSV serta parser CSV ketat.
- Parser CSV memproses 10.000 baris valid dan menolak tiga bentuk CSV rusak.
- Tes simulasi native memastikan `ok:false` dan respons tidak terstruktur tidak dilaporkan berhasil.

## Belum dapat diverifikasi di sesi ini
- Build APK belum dapat dilakukan karena Android project, Android SDK/Gradle wrapper, dan node_modules tidak tersedia di lingkungan ini.
- Printer RAWBT fisik, izin penyimpanan Android, perangkat HP, dan server Cloud nyata masih harus diuji pada perangkat.
