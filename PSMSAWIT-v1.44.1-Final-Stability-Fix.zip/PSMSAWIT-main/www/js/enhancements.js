/* PSM SAWIT - 7 penyempurnaan ringan.
 * Tidak mengubah format nota/laporan lama atau rumus transaksi.
 */
const PSM_ENHANCEMENT_BACKUP_PREFIX = 'PSM_PRE_ACTION';

function psmNormalizeText(v) { return String(v == null ? '' : v).trim().toUpperCase().replace(/\s+/g, ' '); }
function psmDuplicateCandidates(candidate, ignoreId) {
    const owner = psmNormalizeText(candidate.owner), driver = psmNormalizeText(candidate.driver);
    return (db || []).filter(x => {
        if (!x) return false;
        if (ignoreId && normalizeId(x.id) === normalizeId(ignoreId)) return false;
        return String(x.date || '') === String(candidate.date || '') &&
            String(x.time || '').slice(0,5) === String(candidate.time || '').slice(0,5) &&
            psmNormalizeText(x.owner) === owner && psmNormalizeText(x.driver) === driver &&
            Number(x.w1) === Number(candidate.w1) && Number(x.w2) === Number(candidate.w2);
    });
}
function psmConfirmDuplicate(candidate, ignoreId) {
    const matches = psmDuplicateCandidates(candidate, ignoreId);
    if (!matches.length) return true;
    const sample = matches.slice(0,3).map(x => `• ${x.id || '-'} | ${x.date || '-'} ${x.time || ''} | ${x.driver || '-'} | T1 ${fNum(x.w1)} / T2 ${fNum(x.w2)}`).join('\n');
    return confirm(`⚠️ KEMUNGKINAN TRANSAKSI GANDA\nDitemukan ${matches.length} transaksi dengan tanggal, jam, pemilik, sopir, dan berat yang sama.\n\n${sample}\n\nJika memang muatan berbeda, pilih OK untuk tetap menyimpan.`);
}
function psmSetPendingSyncIndicator() {
    const pending = (Array.isArray(db) ? db.filter(x => x && !x.synced).length : 0) +
        (typeof getPendingDeleteIds === 'function' ? getPendingDeleteIds().length : 0);
    const status = document.getElementById('sync-status');
    if (!status) return;
    if (pending > 0) {
        status.textContent = `☁️ ${pending} BELUM TERSINKRON`;
        status.style.display = 'inline-block';
        status.style.background = '#b45309';
        status.style.color = '#fff';
        status.title = 'Ada perubahan yang masih menunggu sinkronisasi Cloud';
    } else if (!window.isSyncing) {
        status.textContent = '☁️ TERSINKRON';
        status.style.display = 'inline-block';
        status.style.background = '#047857';
        status.style.color = '#fff';
        status.title = 'Tidak ada perubahan yang menunggu sinkronisasi';
    }
    const btn = document.getElementById('btn-sync-now');
    if (btn) btn.style.display = pending > 0 ? 'inline-block' : 'none';
}
function psmConfirmSensitiveAction(action, detail) {
    const first = confirm(`⚠️ KONFIRMASI TINDAKAN\n${action}\n${detail || ''}\n\nApakah Anda yakin ingin melanjutkan?`);
    if (!first) return false;
    return confirm(`KONFIRMASI TERAKHIR\nTindakan ini dapat mengubah atau menghapus data.\n\nTekan OK sekali lagi untuk melanjutkan.`);
}
async function psmCreatePreActionBackup(reason) {
    try {
        const rows = Array.isArray(db) ? db : [];
        const csv = typeof buildCSV === 'function' ? buildCSV(rows) : '';
        if (!csv) return false;
        // CSV fields may legally contain quoted CR/LF. Count parsed records,
        // not physical text lines, otherwise valid owner/driver names break backup.
        if (typeof parseSemicolonCsv !== 'function') return false;
        const parsedBackup = parseSemicolonCsv(csv);
        if (parsedBackup.length !== rows.length + 1) return false;
        const stamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `${PSM_ENHANCEMENT_BACKUP_PREFIX}_${stamp}.csv`;
        const saved = typeof simpanBackupInternal === 'function' && simpanBackupInternal(csv, filename, `pre-${reason || 'action'}`);
        if (saved) {
            const check = typeof loadBackupVault === 'function' ? loadBackupVault().find(x => x.filename === filename) : null;
            if (check && check.csv === csv && Number(check.rows) === rows.length) return true;
        }
        // Jika ruang brankas lokal penuh, coba simpan file eksternal melalui mekanisme backup aplikasi.
        if (typeof saveCsvFile === 'function') {
            const external = await saveCsvFile(csv, filename, { isAuto: true });
            return external === 'native' || external === 'browser';
        }
        return false;
    } catch (e) {
        console.error('Backup sebelum tindakan gagal:', e);
        return false;
    }
}
function psmValidateWeightInputs(w1, w2) {
    if (!Number.isFinite(w1) || !Number.isFinite(w2)) return 'Berat T1 dan T2 harus berupa angka yang valid.';
    if (w1 <= 0 || w2 <= 0) return 'Berat T1 dan T2 wajib lebih dari 0.';
    if (w1 <= w2) return 'T1 (Bruto) harus lebih besar daripada T2 (Tara).';
    return '';
}
function psmShowActivityHelp() {
    const pending = (db || []).filter(x => x && !x.synced).length + (typeof getPendingDeleteIds === 'function' ? getPendingDeleteIds().length : 0);
    alert(pending ? `Status Cloud: ${pending} perubahan belum tersinkron. Pastikan internet aktif, lalu tekan SINKRONISASI SEKARANG.` : 'Status Cloud: tidak ada perubahan yang menunggu sinkronisasi.');
}
window.addEventListener('online', () => { setTimeout(psmSetPendingSyncIndicator, 500); });
window.addEventListener('offline', () => { const s=document.getElementById('sync-status'); if(s){s.textContent='⚠️ OFFLINE';s.style.display='inline-block';s.style.background='#b45309';} });
