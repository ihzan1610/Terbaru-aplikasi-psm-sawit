// ===============================
// PSM SAWIT - sync.js
// Automatic foreground sync with server-side verification and retry queue.
// Existing Cloud URL and Apps Script payload format are preserved.
// ===============================

const DELETE_QUEUE_KEY = 'psm_deleted_queue';
const CLOUD_SYNC_RETRY_MIN_MS = 5000;
const CLOUD_SYNC_RETRY_MAX_MS = 60000;
const CLOUD_SYNC_POLL_MS = 20000;

let cloudSyncRetryTimer = null;
let cloudSyncPollTimer = null;
let cloudSyncRetryDelay = CLOUD_SYNC_RETRY_MIN_MS;
let cloudSyncStarted = false;

function getCloudUrl() {
    if (typeof CONFIG !== 'undefined' && CONFIG.CLOUD_URL) return CONFIG.CLOUD_URL;
    if (window.PSM_CONFIG && window.PSM_CONFIG.CLOUD_URL) return window.PSM_CONFIG.CLOUD_URL;
    if (typeof CLOUD_URL !== 'undefined' && CLOUD_URL) return CLOUD_URL;
    return '';
}

async function postToCloudNoCors(payload) {
    const url = getCloudUrl();
    if (!url.includes('http')) throw new Error('CLOUD_URL belum diisi di js/config.js');

    // Apps Script Web App memakai redirect lintas domain. no-cors dipertahankan
    // agar pola POST aplikasi yang lama tetap kompatibel; keberhasilan tidak
    // disimpulkan dari hasil fetch ini, melainkan diverifikasi lewat doGet().
    await fetch(url, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify(payload),
        cache: 'no-store'
    });
    return true;
}

async function getCloudSnapshot() {
    const url = getCloudUrl();
    if (!url.includes('http')) throw new Error('CLOUD_URL belum diisi di js/config.js');

    const response = await fetch(url, { method: 'GET', cache: 'no-store' });
    if (!response.ok) throw new Error('Server Cloud tidak dapat dibaca (HTTP ' + response.status + ')');

    const result = await response.json();
    const rows = Array.isArray(result) ? result : result && result.data;
    if (!Array.isArray(rows)) throw new Error('Format respons Cloud tidak sesuai; data belum ditandai tersinkron.');
    return rows;
}


function cloudRecordFingerprint(record) {
    // Compare business fields only; ignore server metadata and local sync flags.
    const keys = ['id','date','time','owner','driver','w1','w2','price','fl','fj','fp'];
    const out = {};
    keys.forEach(k => {
        let v = record && record[k];
        if (k === 'id') v = normalizeId(v);
        else if (['w1','w2','price','fl','fj','fp'].includes(k)) v = Number(v || 0);
        else v = String(v == null ? '' : v).trim();
        out[k] = v;
    });
    return JSON.stringify(out);
}

async function clearDeleteQueueForRestoredIds(ids) {
    const restored = new Set((ids || []).map(normalizeId).filter(Boolean));
    if (!restored.size) return;
    deletedQueue = (deletedQueue || []).filter(item => !restored.has(normalizeId(item && item.id)));
    await saveDeletedQueueToStorageSafe();
}

async function saveDeletedQueueToStorageSafe() {
    if (typeof saveDeletedQueueToStorage === 'function') return await saveDeletedQueueToStorage();
    saveDeletedQueue();
}

function saveDeletedQueue() {
    if (typeof saveDeletedQueueToStorage === 'function') saveDeletedQueueToStorage();
    else localStorage.setItem(DELETE_QUEUE_KEY, JSON.stringify(deletedQueue || []));
}

function getDeletedIdSet() {
    return new Set((deletedQueue || []).filter(x => x && x.id).map(x => normalizeId(x.id)));
}

function markDeletedForCloud(ids) {
    if (!Array.isArray(ids)) ids = [ids];
    const existing = getDeletedIdSet();
    const now = new Date().toISOString();
    ids.forEach(id => {
        const safeId = normalizeId(id);
        if (!safeId || existing.has(safeId)) return;
        deletedQueue.push({ id: safeId, deletedAt: now, synced: false });
        existing.add(safeId);
    });
    saveDeletedQueue();
    if (ids.length) {
        const pendingCount = getPendingDeleteIds().length;
        setCloudSyncStatus('🗑️ ' + pendingCount + ' PENGHAPUSAN MENUNGGU KONFIRMASI CLOUD', '#b45309');
    }
    scheduleCloudSync(0);
}

function getPendingDeleteIds() {
    return (deletedQueue || []).filter(x => x && x.id && !x.synced).map(x => normalizeId(x.id));
}

async function pruneDeletedQueue() {
    const previousQueue = (deletedQueue || []).map(x => ({...x}));
    const maxAgeMs = 30 * 24 * 60 * 60 * 1000;
    const now = Date.now();
    deletedQueue = (deletedQueue || []).filter(x => {
        if (!x || !x.id) return false;
        if (!x.synced) return true;
        const t = new Date(x.deletedAt || 0).getTime();
        return Number.isFinite(t) && (now - t) < maxAgeMs;
    });
    const saved = await saveDeletedQueueToStorageSafe();
    if (saved === false) {
        deletedQueue = previousQueue;
        throw new Error('Antrean penghapusan gagal disimpan setelah pembersihan; antrean lama dipertahankan.');
    }
}

async function syncDeletesToCloud() {
    const ids = getPendingDeleteIds();
    if (ids.length === 0) return 0;

    // Kirim perintah hapus dengan ID permanen yang sama. Karena POST no-cors
    // tidak memberi respons yang dapat dibaca, status TIDAK pernah dianggap
    // berhasil sebelum GET berikutnya membuktikan semua ID sudah tidak ada.
    await postToCloudNoCors({ action: 'delete', ids: ids });
    const snapshot = await getCloudSnapshot();
    const remainingIds = new Set(snapshot.filter(x => x && x.id).map(x => normalizeId(x.id)));
    const notDeleted = ids.filter(id => remainingIds.has(id));
    if (notDeleted.length) {
        setCloudSyncStatus('⚠️ ' + notDeleted.length + ' PENGHAPUSAN BELUM TERVERIFIKASI DI CLOUD', '#dc2626');
        throw new Error(notDeleted.length + ' penghapusan belum terkonfirmasi oleh Cloud.');
    }

    const sent = new Set(ids);
    const previousQueue = (deletedQueue || []).map(x => ({...x}));
    deletedQueue.forEach(x => {
        if (x && sent.has(normalizeId(x.id))) {
            x.synced = true;
            x.cloudConfirmedAt = new Date().toISOString();
        }
    });
    const queueSaved = await saveDeletedQueueToStorageSafe();
    if (queueSaved === false) {
        deletedQueue = previousQueue;
        throw new Error('Konfirmasi penghapusan Cloud belum tersimpan ke perangkat; antrean akan dicoba ulang.');
    }
    // The confirmed state is now durable. Failure to prune old history must
    // not turn a confirmed remote delete back into a pending in-memory delete.
    const confirmedQueue = (deletedQueue || []).map(x => ({...x}));
    try { await pruneDeletedQueue(); }
    catch (e) {
        deletedQueue = confirmedQueue;
        console.warn('Pembersihan riwayat antrean ditunda; konfirmasi Cloud tetap tersimpan:', e);
    }
    return ids.length;
}

async function tarikDataCloud() {
    beepClick();
    const url = getCloudUrl();
    if (!url.includes('http')) {
        beepError();
        return alert('CLOUD_URL belum diisi di js/config.js');
    }

    const pInput = prompt('FITUR BERBAHAYA!\nMasukkan PIN Akses untuk melanjutkan:');
    if (!(await psmVerifyPin(pInput))) {
        beepError();
        return alert('PIN SALAH! Akses ditolak.');
    }

    const unsynced = db.filter(x => !x.synced).length + getPendingDeleteIds().length;
    if (unsynced > 0) {
        const lanjut = confirm(`Peringatan!\nAda ${unsynced} data/perubahan yang BELUM tersimpan ke Cloud.\nJika Anda tarik data sekarang, perubahan lokal bisa tertimpa.\n\nYakin lanjut tarik data?`);
        if (!lanjut) return;
    }

    const konfirmasi = (typeof psmConfirmSensitiveAction === 'function') ? psmConfirmSensitiveAction('TARIK DATA CLOUD', 'Semua data lokal akan diganti dengan data yang dikirim Cloud.') : confirm('KONFIRMASI TERAKHIR:\nSemua data lokal akan diganti dengan data dari Cloud. Setuju?');
    if (!konfirmasi) return;
    if (!navigator.onLine) {
        beepError();
        return alert('Koneksi Internet dibutuhkan!');
    }

    const s = document.getElementById('sync-status');
    if (s) {
        s.style.display = 'inline-block';
        s.innerText = '⏳ Menarik...';
        s.style.background = '#3b82f6';
    }

    try {
        const rows = await getCloudSnapshot();
        if (typeof psmCreatePreActionBackup === 'function' && !(await psmCreatePreActionBackup('tarik-cloud'))) {
            throw new Error('Backup otomatis sebelum tarik data gagal diverifikasi. Data lokal tidak diubah.');
        }
        const deletedIds = getDeletedIdSet();
        const previousDb = db;
        db = rows.filter(item => item && item.id && !deletedIds.has(normalizeId(item.id)));
        db.forEach(item => {
            item.id = normalizeId(item.id);
            item.synced = true;
        });

        let localSaved = true;
        if (typeof saveDbToStorage === 'function') localSaved = await saveDbToStorage();
        else {
            try { localStorage.setItem('psm_database_master', JSON.stringify(db)); }
            catch (_) { localSaved = false; }
        }
        if (localSaved === false) {
            db = previousDb;
            throw new Error('Data Cloud berhasil dibaca, tetapi gagal disimpan ke perangkat. Data lokal lama dipertahankan.');
        }

        const owners = new Set();
        const drivers = new Set();
        db.forEach(x => {
            if (x.owner) owners.add(x.owner);
            if (x.driver) drivers.add(x.driver);
        });
        // These lists are convenience indexes; their failure must not undo the
        // successfully persisted transaction database.
        try {
            localStorage.setItem('psm_owners', JSON.stringify([...owners]));
            localStorage.setItem('psm_drivers', JSON.stringify([...drivers]));
        } catch (auxError) {
            console.warn('Daftar pemilik/sopir belum dapat diperbarui; data transaksi tetap tersimpan:', auxError);
        }

        beepSuccess();
        alert('BERHASIL! ' + db.length + ' data ditarik. Data yang pernah dihapus lokal tetap disembunyikan.');
        closeSettings();
        mulaiAplikasi();
    } catch (e) {
        beepError();
        alert('Gagal: ' + e.message);
    } finally {
        if (s) s.style.display = 'none';
    }
}

function hasPendingCloudChanges() {
    return (Array.isArray(db) && db.some(x => x && !x.synced)) || getPendingDeleteIds().length > 0;
}

function setCloudSyncStatus(message, color) {
    const status = document.getElementById('sync-status');
    if (!status) return;
    status.style.display = 'inline-block';
    status.innerText = message;
    status.style.background = color;
}

function queueNativeBackgroundSync(records, deleteIds) {
    try {
        const bridge = window.AndroidCloudSync;
        if (!bridge || typeof bridge.enqueue !== 'function') return false;
        const url = getCloudUrl();
        if (!url || !url.includes('http')) return false;
        const ok = bridge.enqueue(url, JSON.stringify(records || []), JSON.stringify(deleteIds || []));
        if (ok) console.log('Antrean sinkronisasi diserahkan ke WorkManager Android.');
        return !!ok;
    } catch (e) {
        console.warn('WorkManager tidak tersedia; retry foreground tetap aktif:', e);
        return false;
    }
}

function scheduleCloudSync(delay) {
    updateManualSyncButton();
    if (!cloudSyncStarted || !hasPendingCloudChanges()) return;
    if (cloudSyncRetryTimer) clearTimeout(cloudSyncRetryTimer);
    cloudSyncRetryTimer = setTimeout(() => {
        cloudSyncRetryTimer = null;
        syncToCloud();
    }, Math.max(0, delay || 0));
}

function startCloudAutoSync() {
    if (cloudSyncStarted) return;
    cloudSyncStarted = true;

    const retryNow = () => {
        // Jangan menimpa jeda retry bertahap yang sudah dijadwalkan setelah gagal.
        if (navigator.onLine && hasPendingCloudChanges() && !cloudSyncRetryTimer) scheduleCloudSync(0);
    };

    window.addEventListener('online', retryNow);
    window.addEventListener('focus', retryNow);
    window.addEventListener('pageshow', retryNow);
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') retryNow();
    });

    // Poll berkala selama aplikasi/halaman masih hidup. Ini bukan jaminan
    // background ketika Android benar-benar menutup proses aplikasi.
    cloudSyncPollTimer = setInterval(retryNow, CLOUD_SYNC_POLL_MS);
    retryNow();
    updateManualSyncButton();
}

async function syncToCloud() {
    updateManualSyncButton();
    const url = getCloudUrl();
    const unsyncedData = (db || []).filter(x => x && !x.synced && x.id);
    const pendingDeleteIds = getPendingDeleteIds();
    if (unsyncedData.length === 0 && pendingDeleteIds.length === 0) { updateManualSyncButton(); return true; }

    // Serahkan salinan antrean ke Android sebelum mencoba upload foreground.
    // WorkManager hanya aktif bila aplikasi berjalan sebagai APK Android.
    queueNativeBackgroundSync(unsyncedData, pendingDeleteIds);
    if (!navigator.onLine || !url.includes('http') || isSyncing) return false;

    setCloudSyncStatus('⏳ Sinkronisasi...', '#3b82f6');
    isSyncing = true;

    try {
        if (unsyncedData.length > 0) {
            await postToCloudNoCors(unsyncedData);
            const snapshot = await getCloudSnapshot();
            const cloudById = new Map(snapshot.filter(x => x && x.id).map(x => [normalizeId(x.id), x]));
            const sentIds = unsyncedData.map(x => normalizeId(x.id));
            const mismatchedIds = unsyncedData.filter(local => {
                const cloud = cloudById.get(normalizeId(local.id));
                return !cloud || cloudRecordFingerprint(cloud) !== cloudRecordFingerprint(local);
            }).map(x => normalizeId(x.id));
            if (mismatchedIds.length > 0) {
                throw new Error(mismatchedIds.length + ' transaksi belum cocok isinya dengan Cloud; tetap menunggu sinkronisasi.');
            }

            const sentSet = new Set(sentIds);
            const priorSyncFlags = new Map();
            db.forEach(item => {
                if (item && sentSet.has(normalizeId(item.id))) {
                    priorSyncFlags.set(normalizeId(item.id), !!item.synced);
                    item.synced = true;
                }
            });
            let persisted = true;
            if (typeof saveDbToStorage === 'function') persisted = await saveDbToStorage();
            else {
                try { localStorage.setItem('psm_database_master', JSON.stringify(db)); }
                catch (storageError) { persisted = false; }
            }
            if (persisted === false) {
                db.forEach(item => {
                    const id = item && normalizeId(item.id);
                    if (priorSyncFlags.has(id)) item.synced = priorSyncFlags.get(id);
                });
                throw new Error('Cloud sudah menerima data, tetapi status sinkronisasi gagal disimpan di perangkat. Data akan diverifikasi ulang.');
            }
        }

        let confirmedDeleteCount = 0;
        if (pendingDeleteIds.length > 0) confirmedDeleteCount = await syncDeletesToCloud();

        cloudSyncRetryDelay = CLOUD_SYNC_RETRY_MIN_MS;
        if (confirmedDeleteCount > 0) {
            setCloudSyncStatus('✅ ' + confirmedDeleteCount + ' DATA TERKONFIRMASI TERHAPUS DI CLOUD', '#10b981');
        } else {
            setCloudSyncStatus('✅ TERSINKRON', '#10b981');
        }
        if (typeof renderLiveTable === 'function') renderLiveTable();
            if (typeof psmSetPendingSyncIndicator === 'function') psmSetPendingSyncIndicator();
        updateManualSyncButton();
        return true;
    } catch (e) {
        console.warn('Sync tertunda; data tetap dalam antrean lokal:', e);
        const pendingDeletes = getPendingDeleteIds().length;
        setCloudSyncStatus(pendingDeletes > 0 ? '⚠️ ' + pendingDeletes + ' PENGHAPUSAN BELUM DIKONFIRMASI - AKAN DICOBA ULANG' : '☁️ TERTUNDA - AKAN DICOBA ULANG', '#f59e0b');
        updateManualSyncButton();
        scheduleCloudSync(cloudSyncRetryDelay);
        cloudSyncRetryDelay = Math.min(cloudSyncRetryDelay * 2, CLOUD_SYNC_RETRY_MAX_MS);
        return false;
    } finally {
        isSyncing = false;
        // Jika ada perubahan baru (termasuk penghapusan) saat siklus ini berjalan,
        // pastikan antrean berikutnya tetap dijadwalkan dan tidak tertinggal.
        if (hasPendingCloudChanges() && !cloudSyncRetryTimer) {
            scheduleCloudSync(cloudSyncRetryDelay);
        }
        if (!hasPendingCloudChanges()) {
            setTimeout(() => {
                const status = document.getElementById('sync-status');
                if (status && status.innerText === '✅ TERSINKRON') status.style.display = 'none';
            }, 4000);
        }
    }
}

// Manual fallback: hanya digunakan jika antrean belum berhasil terkirim otomatis.
async function forceSyncNow() {
    if (isSyncing) return false;
    if (!navigator.onLine) {
        setCloudSyncStatus('📴 OFFLINE - DATA TETAP TERSIMPAN DI HP', '#b45309');
        if (typeof beepError === 'function') beepError();
        return false;
    }
    if (!hasPendingCloudChanges()) {
        setCloudSyncStatus('✅ SEMUA DATA SUDAH TERSINKRON', '#10b981');
        return true;
    }

    const button = document.getElementById('btn-sync-now');
    if (button) {
        button.disabled = true;
        button.innerText = '⏳ MENGIRIM...';
    }
    try {
        // Paksa satu siklus segera; mekanisme verifikasi dan antrean tetap sama.
        if (cloudSyncRetryTimer) clearTimeout(cloudSyncRetryTimer);
        cloudSyncRetryTimer = null;
        const ok = await syncToCloud();
        if (ok && !hasPendingCloudChanges()) {
            cloudSyncRetryDelay = CLOUD_SYNC_RETRY_MIN_MS;
            if (typeof beepSuccess === 'function') beepSuccess();
        }
        return ok;
    } finally {
        if (button) {
            button.disabled = false;
            button.innerText = '☁️ SINKRONISASI SEKARANG';
        }
        updateManualSyncButton();
    }
}

function updateManualSyncButton() {
    const button = document.getElementById('btn-sync-now');
    const status = document.getElementById('sync-status');
    const pending = hasPendingCloudChanges();
    if (button) {
        button.style.display = pending ? 'inline-flex' : 'none';
        button.disabled = !!isSyncing;
        button.title = pending ? 'Ada data/perubahan yang menunggu sinkronisasi Cloud' : '';
        if (pending && !isSyncing) button.innerText = '☁️ SINKRONISASI SEKARANG';
    }
    if (status && !pending && !isSyncing) {
        status.style.display = 'inline-block';
        status.innerText = '✅ TERSINKRON';
        status.style.background = 'transparent';
        status.style.color = '#ffffff';
    } else if (status && pending && !isSyncing) {
        status.style.display = 'inline-block';
        status.innerText = '⚠️ BELUM TERSINKRON';
        status.style.background = 'transparent';
        status.style.color = '#fff3cd';
    }
}
