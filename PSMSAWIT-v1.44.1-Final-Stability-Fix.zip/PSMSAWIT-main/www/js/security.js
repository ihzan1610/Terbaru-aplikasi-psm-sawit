// ===============================
// PSM SAWIT - security.js
// Step 2 modular split.
// ===============================

    const PSM_PIN_HASH_KEY = 'psm_pin_hash_v1';
    const PSM_PIN_SALT_KEY = 'psm_pin_salt_v1';
    const PSM_PIN_FAIL_KEY = 'psm_pin_failures_v1';
    const PSM_PIN_LOCK_KEY = 'psm_pin_lock_until_v1';

    function getPin() {
        const encoded = localStorage.getItem('psm_px');
        if (encoded) { try { return atob(encoded); } catch (_) {} }
        const oldPin = localStorage.getItem('psm_pin');
        return oldPin || '1234';
    }
    async function psmHashPin(pin, salt) {
        if (!window.crypto || !crypto.subtle) throw new Error('Perangkat tidak mendukung penyimpanan PIN aman.');
        const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(String(pin)), 'PBKDF2', false, ['deriveBits']);
        const bits = await crypto.subtle.deriveBits({name:'PBKDF2', salt, iterations:150000, hash:'SHA-256'}, material, 256);
        return Array.from(new Uint8Array(bits)).map(x => x.toString(16).padStart(2,'0')).join('');
    }
    async function savePin(newP) {
        if (window.crypto && crypto.subtle) {
            const salt = crypto.getRandomValues(new Uint8Array(16));
            const hash = await psmHashPin(newP, salt);
            localStorage.setItem(PSM_PIN_SALT_KEY, btoa(String.fromCharCode(...salt)));
            localStorage.setItem(PSM_PIN_HASH_KEY, hash);
            localStorage.removeItem('psm_px');
            localStorage.removeItem('psm_pin');
        } else {
            // Compatibility fallback for older WebViews; keep existing legacy format.
            localStorage.setItem('psm_px', btoa(newP));
        }
    }
    async function psmVerifyPin(candidate) {
        const lockedUntil = Number(localStorage.getItem(PSM_PIN_LOCK_KEY) || 0);
        if (Date.now() < lockedUntil) return false;
        let valid = false;
        const hash = localStorage.getItem(PSM_PIN_HASH_KEY);
        if (hash) {
            try {
                const salt = Uint8Array.from(atob(localStorage.getItem(PSM_PIN_SALT_KEY) || ''), c => c.charCodeAt(0));
                valid = (await psmHashPin(candidate, salt)) === hash;
            } catch (err) { console.warn('Verifikasi PIN aman gagal:', err); return false; }
        } else {
            valid = String(candidate) === getPin();
            // Upgrade old Base64/plain legacy PIN immediately after successful verification.
            if (valid && window.crypto && crypto.subtle) await savePin(String(candidate));
        }
        if (valid) {
            localStorage.removeItem(PSM_PIN_FAIL_KEY);
            localStorage.removeItem(PSM_PIN_LOCK_KEY);
            return true;
        }
        const failures = Number(localStorage.getItem(PSM_PIN_FAIL_KEY) || 0) + 1;
        localStorage.setItem(PSM_PIN_FAIL_KEY, String(failures));
        if (failures >= 5) {
            localStorage.setItem(PSM_PIN_LOCK_KEY, String(Date.now() + 60000));
            localStorage.setItem(PSM_PIN_FAIL_KEY, '0');
        }
        return false;
    }

    async function cekPin() {
        if(await psmVerifyPin(document.getElementById('input-pin').value)) {
            sessionStorage.setItem('psm_unlocked', 'true');
            document.getElementById('lock-screen').style.display = 'none';
            beepClick();
            mulaiAplikasi();
        } else { beepError(); alert("PIN Salah!"); document.getElementById('input-pin').value = ""; }
    }
    const inputPinEl = document.getElementById('input-pin');
    if (inputPinEl) {
        inputPinEl.addEventListener("keypress", function(e) { if (e.key === "Enter") cekPin(); });
    }

    async function ubahPin() {
        beepClick();
        let oldP = document.getElementById('pin-lama').value;
        let newP = document.getElementById('pin-baru').value;
        if(!(await psmVerifyPin(oldP))) { beepError(); return alert("PIN Lama Anda salah atau sementara terkunci."); }
        if(newP.length < 4) { beepError(); return alert("PIN Baru harus minimal 4 angka!"); }
        await savePin(newP); 
        beepSuccess();
        alert("PIN berhasil diubah! Ingat PIN baru Anda.");
        document.getElementById('pin-lama').value = ""; document.getElementById('pin-baru').value = "";
    }


function showGuestInfo() {
    beepClick();
    alert('Mode tamu tidak diaktifkan pada APK lapangan agar data tetap aman. Silakan masuk memakai PIN akses.');
}
