// ===============================
// PSM SAWIT - state.js
// Step 5: state + IndexedDB bridge.
// ===============================

const CLOUD_URL = (window.PSM_CONFIG && window.PSM_CONFIG.CLOUD_URL) ? window.PSM_CONFIG.CLOUD_URL : '';

// Data utama tetap tersedia sebagai array global agar semua fitur lama tidak berubah.
// Pada Step 5, array ini diisi ulang dari IndexedDB saat aplikasi start.
function psmReadLocalJson(key, fallback) {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
    catch (err) { console.warn('Data lokal rusak pada', key, '- memakai nilai aman sementara:', err); return fallback; }
}
let db = psmReadLocalJson('psm_database_master', []);
if (!Array.isArray(db)) db = [];
let mem = psmReadLocalJson('psm_mem_master', {});
if (!mem || typeof mem !== 'object' || Array.isArray(mem)) mem = {};
let savedOwners = psmReadLocalJson('psm_owners', []);
if (!Array.isArray(savedOwners)) savedOwners = [];
let savedDrivers = psmReadLocalJson('psm_drivers', []);
if (!Array.isArray(savedDrivers)) savedDrivers = [];
let curIdx = -1, isEditMode = false, lastData = null;
let selectedIds = new Set();
let isSyncing = false;

// Queue khusus data yang dihapus.
// Pada Step 5, queue ini juga disimpan ke IndexedDB.
let deletedQueue = psmReadLocalJson('psm_deleted_queue', []);
if (!Array.isArray(deletedQueue)) deletedQueue = [];
