# PSM SAWIT v1.44.1 — Final Stability Fix

## Fokus perbaikan
- RAWBT fallback hanya dianggap berhasil jika Android mengonfirmasi bahwa aplikasi eksternal berhasil dibuka; pesan pengguna secara eksplisit menyatakan bahwa keluarnya kertas tetap harus diperiksa pada printer.
- Native Android tidak lagi menganggap perubahan `location.href` sebagai bukti bahwa RAWBT telah terbuka.
- Cetak thermal dan rekap langsir memeriksa ACK JSON dari JavascriptInterface; respons `QUEUED`, teks acak, atau `ok:false` tidak dianggap berhasil.
- Pengunci cetak diperpanjang menjadi 1,8 detik sebagai perlindungan double-tap setelah proses handoff. Ini bukan indikator selesainya cetak fisik.
- Backup pra-tindakan dan metadata jumlah baris brankas menghitung record CSV hasil parsing, sehingga nama pemilik/sopir yang berisi CR/LF bertanda kutip tidak salah dihitung.
- Restore membedakan keberhasilan penyimpanan lokal dari status sinkronisasi Cloud. Restore lokal tidak dilaporkan sebagai sinkronisasi Cloud yang sukses jika verifikasi Cloud tertunda.
- Tarik Cloud menunggu hasil persistensi lokal dan mengembalikan database lama di memori jika penyimpanan lokal gagal.
- Sinkronisasi upload menunggu penyimpanan flag `synced`; bila persistensi gagal, flag dikembalikan agar retry tidak kehilangan status.
- Sinkronisasi antrean penghapusan menunggu persistensi antrean sebelum menyatakan siklus selesai.

## Fitur yang dipertahankan
Tidak ada menu, alur bisnis, format nota, atau rumus transaksi yang sengaja dihapus. Format payload Cloud dan format CSV PSM SAWIT tetap dipertahankan.

## Validasi
Jalankan:
```bash
find www/js scripts tests -type f \( -name "*.js" -o -name "*.cjs" \) -print0 | xargs -0 -n1 node --check
npm run test:all
node scripts/verify-package.js
```

## Batas yang harus diketahui
- Android `startActivity` / AppLauncher hanya membuktikan permintaan diserahkan atau aplikasi RAWBT dibuka, bukan printer benar-benar mengeluarkan kertas. Pengguna harus memeriksa hasil fisik.
- APK belum dibangun di lingkungan ini karena Android SDK dan proyek Android hasil generate tidak tersedia. Workflow GitHub Actions disediakan untuk membangun APK.
- Printer Bluetooth, izin Android, dan endpoint Google Apps Script harus diuji pada perangkat dan akun nyata sebelum penggunaan operasional.
