const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={
  db:[{id:'A1',date:'2026-11-05',time:'08:15',owner:'OWNER A',driver:'DRIVER X',w1:8500,w2:2000,synced:true}],
  normalizeId:x=>String(x||'').trim(), fNum:x=>String(x),
  confirm:()=>true, alert:()=>{}, console, Date, Math, Number, String, Array, Set,
  window:{addEventListener:()=>{},isSyncing:false}, document:{getElementById:()=>null},
  getPendingDeleteIds:()=>[]
};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('www/js/enhancements.js','utf8'),ctx);
assert.equal(vm.runInContext("psmDuplicateCandidates({date:'2026-11-05',time:'08:15',owner:'owner a',driver:'driver x',w1:8500,w2:2000},null).length",ctx),1);
assert.equal(vm.runInContext("psmDuplicateCandidates({date:'2026-11-05',time:'08:15',owner:'owner a',driver:'driver x',w1:8501,w2:2000},null).length",ctx),0);
assert.equal(vm.runInContext("psmValidateWeightInputs(8500,2000)",ctx),'');
assert.ok(vm.runInContext("psmValidateWeightInputs(1000,2000)",ctx));
assert.ok(vm.runInContext("psmValidateWeightInputs(0,0)",ctx));
console.log('ENHANCEMENT_UNIT_TESTS_PASS');

// Regression checks for hardened CSV and Cloud verification helpers.
const backupCtx={
  console,Date,Math,Number,String,Array,Set,Blob,
  normalizeId:x=>String(x||'').trim(), safeText:x=>String(x||''),
  window:{}, document:{getElementById:()=>null}, localStorage:{getItem:()=>null,setItem:()=>{}},
  db:[], deletedQueue:[], selectedIds:new Set(),
  beepClick:()=>{},beepError:()=>{},beepSuccess:()=>{},
};
vm.createContext(backupCtx);
vm.runInContext(fs.readFileSync('www/js/backup.js','utf8'),backupCtx);
const csv=vm.runInContext("buildCSV([{id:'X1',date:'2026-11-05',time:'08:00',owner:'PEMILIK; SATU',driver:'Sopir \\\"A\\\"',w1:8500,w2:2000,price:3000,fl:0,fj:0,fp:0}])",backupCtx);
backupCtx.csvInput=csv;
assert.equal(vm.runInContext("validateRestoreRows(parseSemicolonCsv(csvInput)).length",backupCtx),1);
assert.ok(vm.runInContext("parseSemicolonCsv(csvInput)[1][3]",backupCtx)==='PEMILIK; SATU');
assert.throws(()=>vm.runInContext("validateRestoreRows(parseSemicolonCsv('ID;Tgl;Jam;Own;Dri;T1;T2;P;L;J;Pn\\nX;2026-11-05;08:00;A;B;10;2;3;0;0;0\\nX;2026-11-05;09:00;A;B;10;2;3;0;0;0'))",backupCtx));
const syncCtx={console,Date,Math,Number,String,Array,Set,Map,JSON, navigator:{onLine:true},window:{},document:{getElementById:()=>null},localStorage:{getItem:()=>null,setItem:()=>{}},normalizeId:x=>String(x||'').trim(),db:[],deletedQueue:[]};
vm.createContext(syncCtx); vm.runInContext(fs.readFileSync('www/js/sync.js','utf8'),syncCtx);
assert.equal(vm.runInContext("cloudRecordFingerprint({id:'X',date:'2026-11-05',time:'08:00',owner:'A',driver:'B',w1:'8500',w2:'2000',price:'3000',fl:0,fj:0,fp:0}) === cloudRecordFingerprint({id:'X',date:'2026-11-05',time:'08:00',owner:'A',driver:'B',w1:8500,w2:2000,price:3000,fl:0,fj:0,fp:0})",syncCtx),true);
console.log('DATA_SAFETY_REGRESSION_TESTS_PASS');
