const fs = require('fs');
const vm = require('vm');
const assert = require('assert');

// Strict native response contract: only explicit ok:true counts as success.
const nativeSource = fs.readFileSync('www/js/native.js', 'utf8');
const parserMatch = nativeSource.match(/function parseNativeJsonResult\([\s\S]*?\n    }\n\n    function requireNativeSuccess/);
assert(parserMatch, 'native response parser exists');
const parserCode = parserMatch[0].replace(/\n\n    function requireNativeSuccess[\s\S]*$/, '');
const parserCtx = { JSON, String };
vm.createContext(parserCtx);
vm.runInContext(parserCode, parserCtx);
assert.strictEqual(vm.runInContext("parseNativeJsonResult('{\"ok\":false,\"message\":\"disk full\"}','test').ok", parserCtx), false);
assert.strictEqual(vm.runInContext("parseNativeJsonResult('{\"ok\":true}','test').ok", parserCtx), true);
assert.strictEqual(vm.runInContext("parseNativeJsonResult('QUEUED','test').ok", parserCtx), false);
assert.strictEqual(vm.runInContext("parseNativeJsonResult('', 'test').ok", parserCtx), false);

// Exercise public APK bridge paths with deterministic native failures.
const pluginMap = {
  PsmNative: { saveImage: async () => ({ ok: false, message: 'disk full' }), saveCsv: async () => ({ ok: false, message: 'disk full' }) },
  ImageSaver: { saveBase64: async () => ({ ok: false, message: 'disk full' }) },
  CsvSaver: { save: async () => ({ ok: false, message: 'disk full' }) },
  RawBT: { print: async () => ({ ok: false, message: 'printer missing' }), printBase64Bytes: async () => ({ ok: false, message: 'printer missing' }) },
  AppLauncher: { openUrl: async () => { throw new Error('no handler'); } }
};
const alerts = [];
const fakeWindow = {
  Capacitor: { isNativePlatform: () => true, registerPlugin: name => pluginMap[name] || null },
  AndroidImageSaver: { isReady: () => true, save: () => '{"ok":false,"message":"disk full"}' },
  AndroidCsvSaver: { isReady: () => true, save: () => '{"ok":false,"message":"disk full"}' },
  AndroidRawBT: { isReady: () => true, print: () => '{"ok":false,"message":"printer missing"}', printBase64Bytes: () => '{"ok":false,"message":"printer missing"}' },
  getComputedStyle: () => ({display:'none',visibility:'visible',opacity:'1'}),
  location: { href: '' },
  setTimeout,
  dispatchEvent: () => {}
};
const fakeDocument = {
  addEventListener: () => {},
  getElementById: () => null,
  createElement: () => ({style:{}, appendChild:()=>{}, removeChild:()=>{}, click:()=>{}}),
  body: { appendChild:()=>{} },
  title: 'PSM SAWIT'
};
const quietConsole = { log:()=>{}, warn:()=>{}, error:()=>{} };
const nativeCtx = {
  window: fakeWindow, document: fakeDocument, console:quietConsole, Date, String, Number, JSON, Math,
  TextEncoder, Uint8Array, Array, Promise, setTimeout, clearTimeout,
  alert: message => alerts.push(String(message)), btoa: s => Buffer.from(s, 'binary').toString('base64'),
  history: {back:()=>{}}, location: fakeWindow.location
};
vm.createContext(nativeCtx);
vm.runInContext(nativeSource, nativeCtx);
(async () => {
  const imageResult = await fakeWindow.NativeBridge.saveImage('data:image/png;base64,AAAA', 'test.png');
  assert.strictEqual(imageResult, false, 'failed native image save must not be reported as success');
  const csvResult = await fakeWindow.NativeBridge.saveCsv('ID;Tgl\nA;2026', 'test.csv', {silent:true});
  assert.strictEqual(csvResult, false, 'failed native CSV save must not be reported as success');
  const printResult = await fakeWindow.NativeBridge.printRawBT('TEST PRINT');
  assert.strictEqual(printResult, false, 'failed native print must not be reported as success');
  assert.ok(alerts.some(x => /belum berhasil disimpan|Gagal membuka RAWBT/i.test(x)), 'failure feedback is shown');
  console.log('NATIVE_FAILURE_ACK_TESTS_PASS');
})().catch(err => { console.error(err); process.exitCode = 1; });

// Strict CSV parser regression cases, including quoted-field grammar.
const backupCtx = {
  console, Date, Math, Number, String, Array, Set, Blob,
  normalizeId:x=>String(x||'').trim(), safeText:x=>String(x||''),
  window:{}, document:{getElementById:()=>null}, localStorage:{getItem:()=>null,setItem:()=>{}},
  db:[], deletedQueue:[], selectedIds:new Set(), beepClick:()=>{}, beepError:()=>{}, beepSuccess:()=>{}
};
vm.createContext(backupCtx);
vm.runInContext(fs.readFileSync('www/js/backup.js','utf8'), backupCtx);
for (const bad of [
  'ID;Tgl;Jam;Own;Dri;T1;T2;P;L;J;Pn\nX;d;t;A"B;D;10;1;2;0;0;0',
  'ID;Tgl;Jam;Own;Dri;T1;T2;P;L;J;Pn\nX;d;t;"AB"garbage;D;10;1;2;0;0;0',
  'ID;Tgl;Jam;Own;Dri;T1;T2;P;L;J;Pn\rX;d;t;A;D;10;1;2;0;0;0'
]) assert.throws(() => vm.runInContext(`parseSemicolonCsv(${JSON.stringify(bad)})`, backupCtx));
const largeRows = 10000;
const largeCsv = 'ID;Tgl;Jam;Own;Dri;T1;T2;P;L;J;Pn\r\n' + Array.from({length:largeRows}, (_,i)=>`ID${i};2026-11-05;08:00;OWNER;DRIVER;8500;2000;3000;0;0;0`).join('\r\n');
backupCtx.largeCsv = largeCsv;
assert.strictEqual(vm.runInContext('validateRestoreRows(parseSemicolonCsv(largeCsv)).length', backupCtx), largeRows);
console.log('STRICT_CSV_10000_ROW_STRESS_TEST_PASS');

// Storage layer must expose total persistence failure instead of silently swallowing it.
const dbSource = fs.readFileSync('www/js/db.js', 'utf8');
const saveMatch = dbSource.match(/function saveDbToStorage\(\) \{[\s\S]*?\n\}\n\nfunction psmNotifyStorageIssue\([\s\S]*?\n\}/);
assert(saveMatch, 'storage persistence functions exist');
const storageCtx = {
  db:[{id:'STRESS-1'}], normalizeDbOrder:()=>{}, psmDbWriteQueue:Promise.resolve(),
  psmIDBReady:false, saveDbToIndexedDB:async()=>true,
  LOCAL_DB_KEY:'db', LOCAL_DB_TS_KEY:'ts',
  localStorage:{setItem:()=>{throw new Error('quota exceeded');}},
  window:{dispatchEvent:()=>{storageCtx.warned=true;}}, CustomEvent:function(name,opts){this.type=name;this.detail=opts.detail;},
  console:quietConsole, Date, Promise, JSON
};
vm.createContext(storageCtx);
vm.runInContext(saveMatch[0], storageCtx);
(async()=>{
  const result = await vm.runInContext('saveDbToStorage()', storageCtx);
  assert.strictEqual(result, false, 'save must fail when IndexedDB is unavailable and localStorage is full');
  assert.strictEqual(storageCtx.warned, true, 'storage failure must emit a visible warning event');
  console.log('TOTAL_STORAGE_FAILURE_IS_NOT_SILENT_PASS');
})().catch(err=>{ console.error(err); process.exitCode=1; });

// v1.44.1: RAWBT AppLauncher is only a handoff, and Android must not report
// success when AppLauncher is unavailable or explicitly declines the request.
async function makeNativeBridgeContext(appLauncher) {
  const pluginMap = { AppLauncher: appLauncher };
  const fakeWindow = {
    Capacitor: { isNativePlatform: () => true, registerPlugin: name => pluginMap[name] || null },
    location: { href: '' },
    getComputedStyle: () => ({ display: 'none', visibility: 'visible', opacity: '1' })
  };
  const fakeDocument = {
    addEventListener: () => {}, getElementById: () => null,
    createElement: () => ({ style: {}, click: () => {} }),
    body: { appendChild: () => {} }, title: 'PSM SAWIT'
  };
  const ctx = {
    window: fakeWindow, document: fakeDocument, console: quietConsole, Date, String, Number, JSON, Math,
    TextEncoder, Uint8Array, Array, Promise, setTimeout, clearTimeout,
    alert: () => {}, btoa: s => Buffer.from(s, 'binary').toString('base64'),
    history: { back: () => {} }, location: fakeWindow.location
  };
  vm.createContext(ctx);
  vm.runInContext(nativeSource, ctx);
  return { ctx, fakeWindow };
}
(async () => {
  let env = await makeNativeBridgeContext(null);
  assert.strictEqual(await env.fakeWindow.NativeBridge.openExternalUrl('rawbt:base64,AAAA'), false,
    'native URL handoff must fail when AppLauncher is absent');
  assert.strictEqual(env.fakeWindow.location.href, '', 'native fallback must not silently navigate WebView');

  env = await makeNativeBridgeContext({ openUrl: async () => ({ completed: false }) });
  assert.strictEqual(await env.fakeWindow.NativeBridge.openExternalUrl('rawbt:base64,AAAA'), false,
    'AppLauncher completed:false must not be success');

  let openedUrl = '';
  env = await makeNativeBridgeContext({ openUrl: async ({url}) => { openedUrl = url; return { completed: true }; } });
  assert.strictEqual(await env.fakeWindow.NativeBridge.openExternalUrl('rawbt:base64,AAAA'), true,
    'explicit AppLauncher handoff can be acknowledged');
  assert.strictEqual(openedUrl, 'rawbt:base64,AAAA');
  console.log('RAWBT_HANDOFF_ACK_TESTS_PASS');
})().catch(err => { console.error(err); process.exitCode = 1; });

// v1.44.1: quoted multiline CSV records must be counted as records, not lines,
// both for automatic pre-action backup and internal vault metadata.
const multilineCtx = {
  db: [{id:'ML-1',date:'2026-11-06',time:'08:00',owner:'PEMILIK\nBARIS DUA',driver:'SOPIR',w1:8500,w2:2000,price:3000,fl:0,fj:0,fp:0}],
  console:quietConsole, Date, Math, Number, String, Array, Set, Blob, JSON,
  window:{addEventListener:()=>{},isSyncing:false}, document:{getElementById:()=>null},
  normalizeId:x=>String(x||'').trim(), fNum:x=>String(x), confirm:()=>true,
  localStorage:{_data:{},getItem(k){return this._data[k]||null;},setItem(k,v){this._data[k]=v;}},
  saveCsvFile:async()=>false
};
vm.createContext(multilineCtx);
vm.runInContext(fs.readFileSync('www/js/backup.js','utf8'), multilineCtx);
vm.runInContext(fs.readFileSync('www/js/enhancements.js','utf8'), multilineCtx);
(async()=>{
  const ok = await vm.runInContext("psmCreatePreActionBackup('multiline-test')", multilineCtx);
  assert.strictEqual(ok, true, 'pre-action backup should accept valid quoted multiline fields');
  const vault = vm.runInContext('loadBackupVault()', multilineCtx);
  assert.strictEqual(vault.length, 1);
  assert.strictEqual(vault[0].rows, 1, 'vault row count must count CSV records, not physical lines');
  multilineCtx.savedVaultCsv = vault[0].csv;
  assert.strictEqual(vm.runInContext('parseSemicolonCsv(savedVaultCsv).length', multilineCtx), 2);
  console.log('MULTILINE_PREACTION_BACKUP_TESTS_PASS');
})().catch(err=>{console.error(err);process.exitCode=1;});

// v1.44.1: the UI-level RAWBT acknowledgement parser rejects QUEUED and false.
const thermalSource = fs.readFileSync('www/js/thermal.js','utf8');
const ackMatch = thermalSource.match(/function psmReadRawbtBridgeAck\([\s\S]*?\n}\n/);
assert(ackMatch, 'thermal RAWBT acknowledgement parser exists');
const ackCtx = { JSON, String };
vm.createContext(ackCtx); vm.runInContext(ackMatch[0], ackCtx);
assert.strictEqual(vm.runInContext("psmReadRawbtBridgeAck('QUEUED').ok", ackCtx), false);
assert.strictEqual(vm.runInContext("psmReadRawbtBridgeAck('{\"ok\":false}').ok", ackCtx), false);
assert.strictEqual(vm.runInContext("psmReadRawbtBridgeAck('{\"ok\":true}').ok", ackCtx), true);
console.log('THERMAL_RAWBT_ACK_PARSER_TESTS_PASS');

// v1.44.1: a Cloud-verified upload is not marked locally synced unless the
// updated sync flags are durably persisted.
const syncPersistCtx = {
  CONFIG: { CLOUD_URL: 'https://example.invalid/exec' },
  db: [{id:'SYNC-1',date:'2026-11-06',time:'08:00',owner:'A',driver:'B',w1:8500,w2:2000,price:3000,fl:0,fj:0,fp:0,synced:false}],
  deletedQueue: [], navigator: {onLine:true}, window: {},
  document: {getElementById:()=>null}, console:quietConsole, Date, Math, Number, String, Array, Set, Map, JSON, Promise,
  isSyncing:false, normalizeId:x=>String(x||'').trim(), updateManualSyncButton:()=>{}, queueNativeBackgroundSync:()=>false,
  setCloudSyncStatus:()=>{}, saveDbToStorage:async()=>false, renderLiveTable:()=>{}, psmSetPendingSyncIndicator:()=>{},
  getPendingDeleteIds:()=>[], scheduleCloudSync:()=>{}, setTimeout:()=>0,
  fetch:async (url,opts)=> opts && opts.method==='POST' ? ({ok:true}) : ({ok:true,json:async()=>syncPersistCtx.db.map(x=>({...x,synced:false}))})
};
vm.createContext(syncPersistCtx);
vm.runInContext(fs.readFileSync('www/js/sync.js','utf8'),syncPersistCtx);
(async()=>{
  const result=await vm.runInContext('syncToCloud()',syncPersistCtx);
  assert.strictEqual(result,false,'sync must not report completion when local synced flag persistence fails');
  assert.strictEqual(syncPersistCtx.db[0].synced,false,'failed local persistence must restore unsynced state for retry');
  console.log('CLOUD_SYNC_PERSISTENCE_ACK_TESTS_PASS');
})().catch(err=>{console.error(err);process.exitCode=1;});

// Repeat CSV parsing/validation to exercise state leakage and mutation across runs.
for (let i=0;i<1000;i++) {
  const csv='ID;Tgl;Jam;Own;Dri;T1;T2;P;L;J;Pn\r\nR'+i+';2026-11-06;08:00;OWNER;DRIVER;8500;2000;3000;0;0;0';
  backupCtx.repeatCsv=csv;
  assert.strictEqual(vm.runInContext('validateRestoreRows(parseSemicolonCsv(repeatCsv)).length',backupCtx),1);
}
console.log('CSV_1000_REPEAT_REGRESSION_TESTS_PASS');

// A confirmed remote delete must remain pending locally if its confirmation
// cannot be persisted; otherwise the in-memory queue could stop retrying.
const deletePersistCtx = {
  CONFIG:{CLOUD_URL:'https://example.invalid/exec'},
  deletedQueue:[{id:'DEL-1',synced:false,deletedAt:new Date().toISOString()}],
  normalizeId:x=>String(x||'').trim(), console:quietConsole, Date, Math, Number, String, Array, Set, Map, JSON, Promise,
  fetch:async (url,opts)=> opts && opts.method==='POST' ? ({ok:true}) : ({ok:true,json:async()=>[]}),
  saveDeletedQueueToStorage:async()=>false, setCloudSyncStatus:()=>{}
};
vm.createContext(deletePersistCtx);
vm.runInContext(fs.readFileSync('www/js/sync.js','utf8'),deletePersistCtx);
(async()=>{
  let failed=false;
  try { await vm.runInContext('syncDeletesToCloud()',deletePersistCtx); }
  catch (_) { failed=true; }
  assert.strictEqual(failed,true,'delete queue persistence failure must keep sync cycle failed');
  assert.strictEqual(deletePersistCtx.deletedQueue[0].synced,false,'delete must remain pending for retry');
  console.log('DELETE_QUEUE_PERSISTENCE_ROLLBACK_TESTS_PASS');
})().catch(err=>{console.error(err);process.exitCode=1;});
